﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RunPythonScript
{
    class StandardAsyncOutputExample
    {
        private static readonly StringBuilder Output = new StringBuilder();
        private static Process CurrentProcess { get; set; }

        public static StringBuilder Errors { get; set; }

        public static StringBuilder Results { get; set; }


        public static void Main()
        {
            var paths = ProcessRunner.GetMyScript();
            var maxCount = 5;
            var args = $"-l {maxCount}";

            var batchFile = "RunScript.cmd";

            paths = ProcessRunner.GetMyScript(batchFile);

            ProcessRunner.ExecuteCommand(paths.workingDirectory, batchFile, 6);

            Console.ReadKey();

            var pythonScript = "MyScript.py";

            paths = ProcessRunner.GetMyScript(pythonScript);

            ProcessRunner.RunPythonWithTimeout(paths, pythonScript, 6);

            Console.ReadKey();
        }
        
        public static void RunPythonWithTimeout(int maxCount, int timeoutInSec)
        {
            // https://stackoverflow.com/questions/10788982/is-there-any-async-equivalent-of-process-start

            var pythonScript = @"MyScript.py";

            var startingFolder = Directory.GetCurrentDirectory() + @"..\..\..\";

            var extensions = new List<string> { ".py" };
            string[] files = Directory.GetFiles(startingFolder, "*.*", SearchOption.AllDirectories)
                .Where(f => extensions.IndexOf(Path.GetExtension(f)) >= 0)
                .ToArray();

            var specificScript = files.FirstOrDefault(file => file.EndsWith(pythonScript));

            var selectedScriptPath = Path.GetFullPath(specificScript);

            var workingDirectory = Path.GetDirectoryName(selectedScriptPath);

            var pythonCommand = "python.exe";
            var pythonPath = GetPath(pythonCommand);
            var pythonFullPath = Path.Combine(pythonPath, pythonCommand);

            var scriptArgs = $"{selectedScriptPath} -l {maxCount}";

            var task = Task.Run(async () =>
            {
                await RunProcessExeAsync(workingDirectory, pythonFullPath, scriptArgs);
            });

            if (task.Wait(timeoutInSec * 1000))
            {
                Console.WriteLine("The Process is Complete on time.");
            }
            else
            {
                Console.WriteLine("The Process timed out, force termination.");
                CurrentProcess.Kill();
            }

            if (Results.Length > 0)
            {
                Console.WriteLine("Results:");
                Console.WriteLine(Results);
            }
            if (Errors.Length > 0)
            {
                Console.WriteLine("Errors:");
                Console.WriteLine(Errors);
            }
        }

        public static async Task<int> RunProcessExeAsync(string workingFolder, string fileName, string args)
        {
            Results = new StringBuilder();
            Errors = new StringBuilder();

            using (var process = new Process
                   {
                       StartInfo =
                       {
                           FileName = fileName,
                           Arguments = args,
                           UseShellExecute = false,
                           CreateNoWindow = true,
                           RedirectStandardOutput = true,
                           RedirectStandardError = true,
                           WorkingDirectory = workingFolder
                       },
                       EnableRaisingEvents = true
                   })
            {
                CurrentProcess = process;

                await RunProcessAsync(process).ConfigureAwait(false);
            }

            return 0;
        }

        private static Task<int> RunProcessAsync(Process process)
        {
            var tcs = new TaskCompletionSource<int>();

            process.Exited += (s, ea) => tcs.SetResult(process.ExitCode);
            process.OutputDataReceived += (s, ea) =>
            {
                var message = ea.Data;
                if (!string.IsNullOrEmpty(message))
                {
                    Results.AppendLine(message);
                    Console.WriteLine(message);
                }
            };
            process.ErrorDataReceived += (s, ea) =>
            {
                var message = ea.Data;
                if (!string.IsNullOrEmpty(message))
                {
                    Errors.AppendLine(message);
                    Console.WriteLine(message);
                }
            };

            bool started = process.Start();
            if (!started)
            {
                //you may allow for the process to be re-used (started = false) 
                //but I'm not sure about the guarantees of the Exited event in such a case
                throw new InvalidOperationException("Could not start process: " + process);
            }

            process.BeginOutputReadLine();
            process.BeginErrorReadLine();

            return tcs.Task;
        }


        public static void RunPython1(int maxCount, int timeLimit)
        {
            var pythonScript = @"MyScript.py";

            var startingFolder = Directory.GetCurrentDirectory() + @"..\..\..\";

            var extensions = new List<string> { ".py" };
            string[] files = Directory.GetFiles(startingFolder, "*.*", SearchOption.AllDirectories)
                .Where(f => extensions.IndexOf(Path.GetExtension(f)) >= 0)
                .ToArray();

            var specificScript = files.FirstOrDefault(file => file.EndsWith(pythonScript));

            if (specificScript == null)
            {
            }

            var selectedScriptPath = Path.GetFullPath(specificScript);

            var workingDirectory = Path.GetDirectoryName(selectedScriptPath);

            var pythonCommand = "python.exe";
            var pythonPath = GetPath(pythonCommand);
            var pythonFullPath = Path.Combine(pythonPath, pythonCommand);

            var scriptArgs = $"{selectedScriptPath} -l {maxCount}";

            _ = ProcessRunner.ExecuteShellCommand(pythonFullPath, scriptArgs, timeLimit);
        }

     
        private static void InterProcOutputHandler(object sendingProcess, DataReceivedEventArgs outLine)
        {
            Console.WriteLine(outLine.Data);
        }

        private static string GetPath(string executableName)
        {
            string result = Environment
                .GetEnvironmentVariable("PATH")
                ?.Split(';')
                .FirstOrDefault(s => File.Exists(Path.Combine(s, executableName)));

            return result;
        }

        private static void RunScript(string scriptCmd = @"RunScript.cmd", string args = "")
        {
            var pythonScript = @"RunScript.cmd";

            var startingFolder = Directory.GetCurrentDirectory() + @"..\..\..\";

            var extensions = new List<string> { ".cmd" };
            string[] files = Directory.GetFiles(startingFolder, "*.*", SearchOption.AllDirectories)
                .Where(f => extensions.IndexOf(Path.GetExtension(f)) >= 0)
                .ToArray();

            var specificScript = files.FirstOrDefault(file => file.EndsWith(pythonScript));

            if (specificScript == null)
            {
                return;
            }

            var selectedScriptPath = Path.GetFullPath(specificScript);

            ProcessStartInfo processStartInfo = new ProcessStartInfo();
            processStartInfo.FileName = selectedScriptPath;
            if (!string.IsNullOrEmpty(args))
                processStartInfo.Arguments = $"{selectedScriptPath} {args}";
            processStartInfo.UseShellExecute = false;
            processStartInfo.RedirectStandardOutput = true;
            var workingDirectory = Path.GetDirectoryName(selectedScriptPath);

            if (workingDirectory != null) processStartInfo.WorkingDirectory = workingDirectory;

            using (Process process = Process.Start(processStartInfo))
            {
                if (process != null)
                {
                    process.OutputDataReceived += new DataReceivedEventHandler(InterProcOutputHandler);
                    process.ErrorDataReceived += new DataReceivedEventHandler(InterProcOutputHandler);

                    process.WaitForExit(10000000);
                }
            }
        }

        private void RunPython(string cmd, string args)
        {
            ProcessStartInfo start = new ProcessStartInfo();
            start.FileName = "python.exe";
            start.Arguments = string.Format("{0} {1}", cmd, args);
            start.UseShellExecute = false;
            start.RedirectStandardOutput = true;
            using (Process process = Process.Start(start))
            {
                if (process != null)
                    using (StreamReader reader = process.StandardOutput)
                    {
                        string result = reader.ReadToEnd();
                        Console.Write(result);
                    }
            }
        }

        private static async Task<int> RunProcessAsync1(Process process, int timeout)
        {
            var tcs = new TaskCompletionSource<int>();

            process.Exited += (s, ea) => tcs.SetResult(process.ExitCode);
            process.OutputDataReceived += (s, ea) =>
            {
                Results.AppendLine(ea.Data).Append(Environment.NewLine);
                Console.WriteLine(ea.Data);
            };
            process.ErrorDataReceived += (s, ea) =>
            {
                Errors.AppendLine(ea.Data).Append(Environment.NewLine);
                Console.WriteLine(ea.Data);
            };

            bool started = process.Start();
            if (!started)
            {
                //you may allow for the process to be re-used (started = false) 
                //but I'm not sure about the guarantees of the Exited event in such a case
                throw new InvalidOperationException("Could not start process: " + process);
            }

            process.BeginOutputReadLine();
            process.BeginErrorReadLine();

            ////
            var waitForExit = WaitForExitAsync(process, timeout);

            var outputBuilder = new StringBuilder();
            var errorBuilder = new StringBuilder();
            var outputCloseEvent = new TaskCompletionSource<bool>();
            var errorCloseEvent = new TaskCompletionSource<bool>();
            var result = new ProcessResult();

            // Create task to wait for process exit and closing all output streams
            var processTask = Task.WhenAll(waitForExit, outputCloseEvent.Task, errorCloseEvent.Task);

            // Waits process completion and then checks it was not completed by timeout
            if (await Task.WhenAny(Task.Delay(timeout), processTask) == processTask && waitForExit.Result)
            {
                result.Completed = true;
                result.ExitCode = process.ExitCode;

                // Adds process output if it was completed with error
                if (process.ExitCode != 0)
                {
                    result.Output = $"{outputBuilder}{errorBuilder}";
                }
            }
            else
            {
                try
                {
                    // Kill hung process
                    process.Kill();
                }
                catch
                {
                }
            }

            //// https://stackoverflow.com/questions/70622033/waitforexitasync-with-a-timeout

            //var timeoutSignal = new CancellationTokenSource(TimeSpan.FromSeconds(3));
            //try
            //{
            //    //await process.WaitForExitAsync(timeoutSignal.Token);
            //    Console.WriteLine("Ping has been Finished");
            //}
            //catch (OperationCanceledException)
            //{
            //    process.Kill();
            //    Console.WriteLine("Ping has been Terminated");
            //}

            return await tcs.Task;
        }

        private static Task<bool> WaitForExitAsync(Process process, int timeout)
        {
            return Task.Run(() => process.WaitForExit(timeout));
        }

    }

    public struct ProcessResult
    {
        public bool Completed;
        public int? ExitCode;
        public string Output;
    }

    // https://gist.github.com/AlexMAS/276eed492bc989e13dcce7c78b9e179d

}



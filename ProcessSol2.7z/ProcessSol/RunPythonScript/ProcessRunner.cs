﻿using System.Collections.Generic;
using System.Linq;
using System.Management;

namespace RunPythonScript
{
    using System;
    using System.Diagnostics;
    using System.IO;
    using System.Text;
    using System.Threading.Tasks;

    public static class ProcessRunner
    {
        private static int _lineCount;

        private static Process CurrentProcess { get; set; }
        private static string CurrentFolder { get; set; }

        public static StringBuilder Errors { get; set; }

        public static StringBuilder Results { get; set; }

        // https://stackoverflow.com/questions/5519328/executing-batch-file-in-c-sharp
        public static void  ExecuteCommand(string workingDirectory, string command, int timeout)
        {
            var processInfo = new ProcessStartInfo("cmd.exe", "/c " + command);
            processInfo.CreateNoWindow = true;
            processInfo.UseShellExecute = false;
            processInfo.RedirectStandardError = true;
            processInfo.RedirectStandardOutput = true;
            processInfo.WorkingDirectory = workingDirectory;

            var process = Process.Start(processInfo);

            process.OutputDataReceived += (object sender, DataReceivedEventArgs e) =>
                Console.WriteLine("output>>" + e.Data);
            process.BeginOutputReadLine();

            process.ErrorDataReceived += (object sender, DataReceivedEventArgs e) =>
                Console.WriteLine("error>>" + e.Data);
            process.BeginErrorReadLine();

            try
            {
                if (process.WaitForExit(timeout * 1000))
                {
                    Console.WriteLine("ExitCode: {0}", process.ExitCode);
                    process.Close();
                }
                else
                {
                    KillChildProcesses(process);
                }
            }
            catch (Exception excep)
            {
                Console.WriteLine(excep);
            }
        }

        public static IEnumerable<Process> GetChildProcesses(Process process)
        {
            var children = new List<Process>();
            var mos = new ManagementObjectSearcher(String.Format("Select * From Win32_Process Where ParentProcessID={0}", process.Id));

            foreach (var mo in mos.Get())
            {
                children.Add(Process.GetProcessById(Convert.ToInt32(mo["ProcessID"])));
            }

            return children;
        }

        private static void KillChildProcesses(Process process)
        {
            foreach (Process childProcess in GetChildProcesses(process))
            {
                KillChildProcesses(childProcess);
                Console.WriteLine("killed process: " + childProcess.ProcessName);
                childProcess.Kill();
            }
        }

        public static (string workingDirectory, string scriptToRun, string scriptRunner) 
            GetMyScript(string scriptName = @"MyScript.py", string seachFromFolder = @"..\..\..\")
        {
            string scriptType = Path.GetExtension(scriptName);

            var startingFolder = Directory.GetCurrentDirectory() + seachFromFolder;

            var extensions = new List<string> { scriptType };
            string[] files = Directory.GetFiles(startingFolder, "*.*", SearchOption.AllDirectories)
                .Where(f => extensions.IndexOf(Path.GetExtension(f)) >= 0)
                .ToArray();

            var specificScript = files.FirstOrDefault(file => file.EndsWith(scriptName));

            var selectedScriptPath = Path.GetFullPath(specificScript);
            var selectedScript = Path.GetFileName(selectedScriptPath);

            var workingDirectory = Path.GetDirectoryName(selectedScriptPath);

            var pythonCommand = "python.exe";
            var pythonPath = GetPath(pythonCommand);
            var pythonFullPath = Path.Combine(pythonPath, pythonCommand);

            return (workingDirectory, selectedScript, pythonFullPath);
        }

        public static void RunPythonWithTimeout(
            (string workingDirectory, string scriptPath, string pythonFullPath) paths,
            string scriptArgs, int timeoutInSec)
        {
            // https://stackoverflow.com/questions/10788982/is-there-any-async-equivalent-of-process-start

            try
            {
                var task = Task.Run(async () => await RunProcessExeAsync(paths, scriptArgs));

                Console.ReadKey();

                if (task.Wait(timeoutInSec * 1000))
                {
                    var processExitCode = task.Result;
                    Console.WriteLine($"The Process is Complete on time: Process Exit Code = {processExitCode}");
                }
                else
                {
                    Console.WriteLine("The Process timed out, force termination.");
                    CurrentProcess.Kill();
                }
            }
            catch (Exception excep)
            {
                Console.WriteLine(excep);
            }

            if (Results.Length > 0)
            {
                Console.WriteLine("Results:");
                Console.WriteLine(Results);
            }
            if (Errors.Length > 0)
            {
                Console.WriteLine("Errors:");
                Console.WriteLine(Errors);
            }
        }

        private static string GetPath(string executableName)
        {
            string result = Environment
                .GetEnvironmentVariable("PATH")
                ?.Split(';')
                .FirstOrDefault(s => File.Exists(Path.Combine(s, executableName)));

            return result;
        }

        public static async Task<int> RunProcessExeAsync(
            (string workingDirectory, string scriptPath, string pythonFullPath) paths,
            string args)
        {
            Results = new StringBuilder();
            Errors = new StringBuilder();
            var workingFolder = paths.workingDirectory;
            var python = paths.pythonFullPath;
            var scriptOnly = Path.GetFileName(paths.scriptPath);
            var scriptArgs = $"{scriptOnly} {args}";
            var runScript = Path.Combine(workingFolder, "RunScript.cmd");
            CurrentFolder = Directory.GetCurrentDirectory();
            Directory.SetCurrentDirectory(workingFolder);

            string[] files = Directory.GetFiles(".", "*.*");
            var cmd = "C:\\Windows\\System32\\cmd.exe";
            var batchScript = ".\\RunScript.cmd";
            var command1 = python;
            var command2 = $"CMD.EXE /C {python}";
            var command3 = $"CMD.EXE /C {python}";
            var command4 = $"START /D {workingFolder} CMD /C {runScript}";
            var command5 = $"{cmd} /C {batchScript}";
            var command = command1;
            //scriptArgs = String.Empty;

            using (var process = new Process
                   {
                       StartInfo =
                       {
                           FileName = command,
                           Arguments = scriptArgs,
                           UseShellExecute = false,
                           CreateNoWindow = true,
                           RedirectStandardOutput = true,
                           RedirectStandardError = true,
                           WorkingDirectory = workingFolder
                       },
                       EnableRaisingEvents = true
                   })
            {
                CurrentProcess = process;

                return await RunProcessAsync(process).ConfigureAwait(false);
            }
        }

        public static void RunSimpleProcess(string fileToExecute)
        {
            Process process = new Process();
            process.StartInfo.FileName = fileToExecute;
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.RedirectStandardOutput = true;
            process.OutputDataReceived += (sender, e) =>
            {
                // Prepend line numbers to each line of the output.
                if (!String.IsNullOrEmpty(e.Data))
                {
                    _lineCount++;
                    Results.Append("\n[" + _lineCount + "]: " + e.Data);
                }
            };

            process.Start();

            // Asynchronously read the standard output of the spawned process.
            // This raises OutputDataReceived events for each line of output.
            process.BeginOutputReadLine();
            process.WaitForExit();

            // Write the redirected output to this application's window.
            Console.WriteLine(Results);

            process.WaitForExit();
            process.Close();

            Console.WriteLine("\n\nPress any key to exit.");
        }

        private static Task<int> RunProcessAsync(Process process)
        {
            var tcs = new TaskCompletionSource<int>();

            process.Exited += (s, ea) => tcs.SetResult(process.ExitCode);
            process.OutputDataReceived += (s, ea) =>
            {
                var message = ea.Data;
                if (!string.IsNullOrEmpty(message))
                {
                    Results.AppendLine(message);
                    Console.WriteLine(message);
                }
            };
            process.ErrorDataReceived += (s, ea) =>
            {
                var message = ea.Data;
                if (!string.IsNullOrEmpty(message))
                {
                    Errors.AppendLine(message);
                    Console.WriteLine(message);
                }
            };

            bool started = process.Start();
            if (!started)
            {
                //you may allow for the process to be re-used (started = false) 
                //but I'm not sure about the guarantees of the Exited event in such a case
                throw new InvalidOperationException("Could not start process: " + process);
            }

            process.BeginOutputReadLine();
            process.BeginErrorReadLine();

            return tcs.Task;
        }

        public static async Task<ProcessResult> ExecuteShellCommand(string command, string arguments, int timeout)
        {
            var result = new ProcessResult();

            using (var process = new Process())
            {
                // If you run bash-script on Linux it is possible that ExitCode can be 255.
                // To fix it you can try to add '#!/bin/bash' header to the script.

                process.StartInfo.FileName = command;
                process.StartInfo.Arguments = arguments;
                process.StartInfo.UseShellExecute = false;
                process.StartInfo.RedirectStandardInput = true;
                process.StartInfo.RedirectStandardOutput = true;
                process.StartInfo.RedirectStandardError = true;
                process.StartInfo.CreateNoWindow = true;

                var outputBuilder = new StringBuilder();
                var outputCloseEvent = new TaskCompletionSource<bool>();

                process.OutputDataReceived += (s, e) =>
                {
                    // The output stream has been closed i.e. the process has terminated
                    if (e.Data == null)
                    {
                        outputCloseEvent.SetResult(true);
                    }
                    else
                    {
                        Console.WriteLine(e.Data);
                        outputBuilder.AppendLine(e.Data);
                    }
                };

                var errorBuilder = new StringBuilder();
                var errorCloseEvent = new TaskCompletionSource<bool>();

                process.ErrorDataReceived += (s, e) =>
                {
                    // The error stream has been closed i.e. the process has terminated
                    if (e.Data == null)
                    {
                        errorCloseEvent.SetResult(true);
                    }
                    else
                    {
                        Console.WriteLine(e.Data);
                        errorBuilder.AppendLine(e.Data);
                    }
                };

                bool isStarted;

                try
                {
                    isStarted = process.Start();
                }
                catch (Exception error)
                {
                    // Usually it occurs when an executable file is not found or is not executable

                    result.Completed = true;
                    result.ExitCode = -1;
                    result.Output = error.Message;

                    isStarted = false;
                }

                if (isStarted)
                {
                    // Reads the output stream first and then waits because deadlocks are possible
                    process.BeginOutputReadLine();
                    process.BeginErrorReadLine();

                    // Creates task to wait for process exit using timeout
                    var waitForExit = WaitForExitAsync(process, timeout);

                    // Create task to wait for process exit and closing all output streams
                    var processTask = Task.WhenAll(waitForExit, outputCloseEvent.Task, errorCloseEvent.Task);

                    // Waits process completion and then checks it was not completed by timeout
                    if (await Task.WhenAny(Task.Delay(timeout), processTask) == processTask && waitForExit.Result)
                    {
                        result.Completed = true;
                        result.ExitCode = process.ExitCode;

                        // Adds process output if it was completed with error
                        if (process.ExitCode != 0)
                        {
                            result.Output = $"{outputBuilder}{errorBuilder}";
                        }
                    }
                    else
                    {
                        try
                        {
                            // Kill hung process
                            process.Kill();
                        }
                        catch
                        {
                        }
                    }
                }
            }

            return result;
        }

        private static Task<bool> WaitForExitAsync(Process process, int timeout)
        {
            return Task.Run(() => process.WaitForExit(timeout));
        }

        public struct ProcessResult
        {
            public bool Completed;
            public int? ExitCode;
            public string Output;
        }
    }
}

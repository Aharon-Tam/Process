﻿using System;
using System.Diagnostics;
using System.Text;

namespace RunIpConfig
{
    // https://learn.microsoft.com/en-us/dotnet/api/system.diagnostics.process.outputdatareceived?view=netframework-4.8.1

    class StandardAsyncOutputExample
    {
        private static int _lineCount;

        private static readonly StringBuilder Results = new StringBuilder();

        public static void Main()
        {
            RunSimpleProcess("ipconfig.exe");

            Console.ReadKey();
        }

        public static void RunSimpleProcess(string fileToExecute)
        {
            Process process = new Process();
            process.StartInfo.FileName = fileToExecute;
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.RedirectStandardOutput = true;
            process.OutputDataReceived += (sender, e) =>
            {
                // Prepend line numbers to each line of the output.
                if (!String.IsNullOrEmpty(e.Data))
                {
                    _lineCount++;
                    Results.Append("\n[" + _lineCount + "]: " + e.Data);
                }
            };

            process.Start();

            // Asynchronously read the standard output of the spawned process.
            // This raises OutputDataReceived events for each line of output.
            process.BeginOutputReadLine();
            process.WaitForExit();

            // Write the redirected output to this application's window.
            Console.WriteLine(Results);

            process.WaitForExit();
            process.Close();

            Console.WriteLine("\n\nPress any key to exit.");
        }
    }
}

﻿using System.Collections.Generic;
using System.Linq;

namespace RunPythonScript
{
    using System;
    using System.Diagnostics;
    using System.IO;
    using System.Text;
    using System.Threading.Tasks;

    public static class ProcessAsyncHelper
    {
        private static int _lineCount;

        private static Process CurrentProcess { get; set; }

        public static StringBuilder Errors { get; set; }

        public static StringBuilder Results { get; set; }

        public static void RunPythonWithTimeout(int maxCount, int timeoutInSec)
        {
            // https://stackoverflow.com/questions/10788982/is-there-any-async-equivalent-of-process-start

            var pythonScript = @"MyScript.py";

            var startingFolder = Directory.GetCurrentDirectory() + @"..\..\..\";

            var extensions = new List<string> { ".py" };
            string[] files = Directory.GetFiles(startingFolder, "*.*", SearchOption.AllDirectories)
                .Where(f => extensions.IndexOf(Path.GetExtension(f)) >= 0)
                .ToArray();

            var specificScript = files.FirstOrDefault(file => file.EndsWith(pythonScript));

            var selectedScriptPath = Path.GetFullPath(specificScript);

            var workingDirectory = Path.GetDirectoryName(selectedScriptPath);

            var pythonCommand = "python.exe";
            var pythonPath = GetPath(pythonCommand);
            var pythonFullPath = Path.Combine(pythonPath, pythonCommand);

            var scriptArgs = $"{selectedScriptPath} -l {maxCount}";

            var task = Task.Run(async () => await RunProcessExeAsync(workingDirectory, pythonFullPath, scriptArgs));

            if (task.Wait(timeoutInSec * 1000))
            {
                var processExitCode = task.Result;
                Console.WriteLine($"The Process is Complete on time: Process Exit Code = {processExitCode}");
            }
            else
            {
                Console.WriteLine("The Process timed out, force termination.");
                CurrentProcess.Kill();
            }

            if (Results.Length > 0)
            {
                Console.WriteLine("Results:");
                Console.WriteLine(Results);
            }
            if (Errors.Length > 0)
            {
                Console.WriteLine("Errors:");
                Console.WriteLine(Errors);
            }
        }

        private static string GetPath(string executableName)
        {
            string result = Environment
                .GetEnvironmentVariable("PATH")
                ?.Split(';')
                .FirstOrDefault(s => File.Exists(Path.Combine(s, executableName)));

            return result;
        }

        public static async Task<int> RunProcessExeAsync(string workingFolder, string fileName, string args)
        {
            Results = new StringBuilder();
            Errors = new StringBuilder();

            using (var process = new Process
            {
                StartInfo =
                       {
                           FileName = fileName,
                           Arguments = args,
                           UseShellExecute = false,
                           CreateNoWindow = true,
                           RedirectStandardOutput = true,
                           RedirectStandardError = true,
                           WorkingDirectory = workingFolder
                       },
                EnableRaisingEvents = true
            })
            {
                CurrentProcess = process;

                return await RunProcessAsync(process).ConfigureAwait(false);
            }
        }

        public static void RunSimpleProcess(string fileToExecute)
        {
            Process process = new Process();
            process.StartInfo.FileName = fileToExecute;
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.RedirectStandardOutput = true;
            process.OutputDataReceived += (sender, e) =>
            {
                // Prepend line numbers to each line of the output.
                if (!String.IsNullOrEmpty(e.Data))
                {
                    _lineCount++;
                    Results.Append("\n[" + _lineCount + "]: " + e.Data);
                }
            };

            process.Start();

            // Asynchronously read the standard output of the spawned process.
            // This raises OutputDataReceived events for each line of output.
            process.BeginOutputReadLine();
            process.WaitForExit();

            // Write the redirected output to this application's window.
            Console.WriteLine(Results);

            process.WaitForExit();
            process.Close();

            Console.WriteLine("\n\nPress any key to exit.");
        }

        private static Task<int> RunProcessAsync(Process process)
        {
            var tcs = new TaskCompletionSource<int>();

            process.Exited += (s, ea) => tcs.SetResult(process.ExitCode);
            process.OutputDataReceived += (s, ea) =>
            {
                var message = ea.Data;
                if (!string.IsNullOrEmpty(message))
                {
                    Results.AppendLine(message);
                    Console.WriteLine(message);
                }
            };
            process.ErrorDataReceived += (s, ea) =>
            {
                var message = ea.Data;
                if (!string.IsNullOrEmpty(message))
                {
                    Errors.AppendLine(message);
                    Console.WriteLine(message);
                }
            };

            bool started = process.Start();
            if (!started)
            {
                //you may allow for the process to be re-used (started = false) 
                //but I'm not sure about the guarantees of the Exited event in such a case
                throw new InvalidOperationException("Could not start process: " + process);
            }

            process.BeginOutputReadLine();
            process.BeginErrorReadLine();

            return tcs.Task;
        }

        public static async Task<ProcessResult> ExecuteShellCommand(string command, string arguments, int timeout)
        {
            var result = new ProcessResult();

            using (var process = new Process())
            {
                // If you run bash-script on Linux it is possible that ExitCode can be 255.
                // To fix it you can try to add '#!/bin/bash' header to the script.

                process.StartInfo.FileName = command;
                process.StartInfo.Arguments = arguments;
                process.StartInfo.UseShellExecute = false;
                process.StartInfo.RedirectStandardInput = true;
                process.StartInfo.RedirectStandardOutput = true;
                process.StartInfo.RedirectStandardError = true;
                process.StartInfo.CreateNoWindow = true;

                var outputBuilder = new StringBuilder();
                var outputCloseEvent = new TaskCompletionSource<bool>();

                process.OutputDataReceived += (s, e) =>
                {
                    // The output stream has been closed i.e. the process has terminated
                    if (e.Data == null)
                    {
                        outputCloseEvent.SetResult(true);
                    }
                    else
                    {
                        Console.WriteLine(e.Data);
                        outputBuilder.AppendLine(e.Data);
                    }
                };

                var errorBuilder = new StringBuilder();
                var errorCloseEvent = new TaskCompletionSource<bool>();

                process.ErrorDataReceived += (s, e) =>
                {
                    // The error stream has been closed i.e. the process has terminated
                    if (e.Data == null)
                    {
                        errorCloseEvent.SetResult(true);
                    }
                    else
                    {
                        Console.WriteLine(e.Data);
                        errorBuilder.AppendLine(e.Data);
                    }
                };

                bool isStarted;

                try
                {
                    isStarted = process.Start();
                }
                catch (Exception error)
                {
                    // Usually it occurs when an executable file is not found or is not executable

                    result.Completed = true;
                    result.ExitCode = -1;
                    result.Output = error.Message;

                    isStarted = false;
                }

                if (isStarted)
                {
                    // Reads the output stream first and then waits because deadlocks are possible
                    process.BeginOutputReadLine();
                    process.BeginErrorReadLine();

                    // Creates task to wait for process exit using timeout
                    var waitForExit = WaitForExitAsync(process, timeout);

                    // Create task to wait for process exit and closing all output streams
                    var processTask = Task.WhenAll(waitForExit, outputCloseEvent.Task, errorCloseEvent.Task);

                    // Waits process completion and then checks it was not completed by timeout
                    if (await Task.WhenAny(Task.Delay(timeout), processTask) == processTask && waitForExit.Result)
                    {
                        result.Completed = true;
                        result.ExitCode = process.ExitCode;

                        // Adds process output if it was completed with error
                        if (process.ExitCode != 0)
                        {
                            result.Output = $"{outputBuilder}{errorBuilder}";
                        }
                    }
                    else
                    {
                        try
                        {
                            // Kill hung process
                            process.Kill();
                        }
                        catch
                        {
                        }
                    }
                }
            }

            return result;
        }

        private static Task<bool> WaitForExitAsync(Process process, int timeout)
        {
            return Task.Run(() => process.WaitForExit(timeout));
        }

        public struct ProcessResult
        {
            public bool Completed;
            public int? ExitCode;
            public string Output;
        }
    }
}

import time
import sys
import argparse

def Worker(max_count):
    count = 1

    print(f'Counting down: {max_count}')

    while(count <= max_count):
        count_down = max_count - count + 1
        print(f'[{count_down}] hello my friend.')
        sys.stdout.flush()
        count = count + 1
        time.sleep(1)

if __name__ == '__main__':
    import argparse

    x = 1000
  
    try:
        parser = argparse.ArgumentParser(description='Simple Counter Program')
        parser.add_argument('-l', '--limit', type=str, help='count up to lime', required=False)
        #parser.add_argument('-b','--bar', help='Description for bar argument', required=True)

        args = parser.parse_args()
        
        r = args.limit
        if r is not None:
            x = int(r)
    except NameError:
        print(f'{NameError}')
    except:
        print("Failed to parse command line args")

    Worker(x)
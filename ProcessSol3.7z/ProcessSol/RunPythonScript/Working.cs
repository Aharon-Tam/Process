﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RunPythonScript
{

    public class Working
    {
        private static Process InterProc;

        // https://stackoverflow.com/questions/40177405/datareceivedevent-not-hit-while-interacting-with-python-process-from-redirecte

        public Working()
        {
            InterProc = new Process();
            InitializeInterpreter();
        }

        private void InitializeInterpreter()
        {
            InterProc.StartInfo.FileName = @"C:\Python27\python.exe";
            InterProc.StartInfo.Arguments =
                @"-i"; // drops python into interactive mode after executing script if passed any
            InterProc.StartInfo.UseShellExecute = false;
            InterProc.StartInfo.RedirectStandardInput = true;
            InterProc.StartInfo.RedirectStandardOutput = true;
            InterProc.StartInfo.RedirectStandardError = true;
            InterProc.StartInfo.CreateNoWindow = true;
            InterProc.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            InterProc.OutputDataReceived += new DataReceivedEventHandler(InterProcOutputHandler);
            InterProc.ErrorDataReceived += new DataReceivedEventHandler(InterProcOutputHandler);

            bool started = InterProc.Start();

            InterProc.BeginOutputReadLine();
            InterProc.BeginErrorReadLine();
        }


        private void InterProcOutputHandler(object sendingProcess, DataReceivedEventArgs outLine)
        {
            Console.WriteLine(outLine.Data);
        }

    }
}

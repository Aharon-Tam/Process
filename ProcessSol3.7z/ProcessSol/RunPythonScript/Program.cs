﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RunPythonScript
{
    class StandardAsyncOutputExample
    {
        private static readonly StringBuilder Output = new StringBuilder();
        private static Process CurrentProcess { get; set; }

        public static StringBuilder Errors { get; set; }

        public static StringBuilder Results { get; set; }

        private static object Locker { get; } = new object();

        private static bool Monitor { get; set; } = false;
        public static void Main()
        {
            UsingManualEventHandlerRun();

            return;

            // 1)
            //var batchFile2 = "PlotScript.py";

            //var paths2 = ProcessRunner.GetMyScript(batchFile2);
            //var workingFolder = paths2.workingDirectory;
            //var scriptRunner = paths2.scriptRunner;

            //var start = new ProcessStartInfo();
            //start.FileName = scriptRunner; // @"C:\Users\Basic User\AppData\Local\Programs\Python\Python38\python.exe";
            //var args2 = $@"{batchFile2} -c 20";

            //var xx = ProcessAsyncHelper.ExecuteShellCommand(
            //    workingFolder,
            //    scriptRunner,
            //    args2, 10000);

            //var results = xx.Result;

            //return;

            //// 2)
            //var task = Task.Run(SecondTry);

            //try
            //{
            //    if (task.Wait(4000))
            //    {
            //        CurrentProcess.Close();
            //    }
            //    else
            //    {
            //        CurrentProcess.Kill();
            //    }
            //}
            //catch (Exception excep)
            //{
            //    Console.WriteLine(excep);
            //}

            //Console.ReadKey();

            //return;

            var paths = ProcessRunner.GetMyScript();
            var maxCount = 5;
            var args = $"-l {maxCount}";

            var batchFile = "RunScript.cmd";

            paths = ProcessRunner.GetMyScript(batchFile);

            ProcessRunner.ExecuteCommand(paths.workingDirectory, batchFile, 6);

            Console.ReadKey();

            var pythonScript = "MyScript.py";

            paths = ProcessRunner.GetMyScript(pythonScript);

            ProcessRunner.RunPythonWithTimeout(paths, pythonScript, 6);

            Console.ReadKey();
        }

        static ManualResetEvent _manualResetEvent = new ManualResetEvent(false);

        private static void UsingManualEventHandlerRun()
        {
            _manualResetEvent = new ManualResetEvent(false);

            Monitor = true;

            var task =  Task.Factory.StartNew(() =>
            {
                ThirdTry(_manualResetEvent);
            });

            var ws = new Stopwatch();
            ws.Start();

            try
            {
                bool isSignalled = _manualResetEvent.WaitOne(TimeSpan.FromSeconds(55));
                if (isSignalled)
                {
                    CurrentProcess.Close();
                }
                else
                {
                    CurrentProcess.Kill();
                }

                Monitor = false;
            }
            catch (Exception excep)
            {
                Console.WriteLine(excep);
            }

            ws.Stop();
            var elapsedMs = ws.ElapsedMilliseconds;
            var secs = elapsedMs / 1000;
            var minutes = (int)(secs / 60);
            var seconds = (int)(secs % 60);

            Console.WriteLine($"Elapsed Time = {minutes:0#}:{seconds:0#}");
            Console.ReadKey();
        }

        private static void UsingManualEventHandlerRun1()
        {
            _manualResetEvent = new ManualResetEvent(false);

            var task = Task.Factory.StartNew(() =>
            {
                ThirdTry(_manualResetEvent);
            });

            var ws = new Stopwatch();
            ws.Start();

            try
            {
                bool isSignalled = _manualResetEvent.WaitOne(TimeSpan.FromSeconds(15));
                if (isSignalled)
                {
                    CurrentProcess.Close();
                }
                else
                {
                    CurrentProcess.Kill();
                }
            }
            catch (Exception excep)
            {
                Console.WriteLine(excep);
            }

            ws.Stop();
            var elapsedMs = ws.ElapsedMilliseconds;
            var secs = elapsedMs / 1000;
            var minutes = (int)(secs / 60);
            var seconds = (int)(secs % 60);

            Console.WriteLine($"Elapsed Time = {minutes:0#}:{seconds:0#}");
            Console.ReadKey();
        }

        private static void ForthTry(ManualResetEvent resetEvent)
        {
            Results = new StringBuilder();
            Errors = new StringBuilder();

            var batchFile = "PlotScript.py";

            var paths = ProcessRunner.GetMyScript(batchFile);
            var workingFolder = paths.workingDirectory;
            var scriptRunner = paths.scriptRunner;

            var start = new ProcessStartInfo();
            start.FileName = scriptRunner; // @"C:\Users\Basic User\AppData\Local\Programs\Python\Python38\python.exe";
            start.Arguments = $@"{batchFile} -c 8";
            start.UseShellExecute = false;
            start.RedirectStandardOutput = true;
            start.RedirectStandardError = true;
            start.CreateNoWindow = true;

            start.WorkingDirectory = workingFolder;

            using (var process = Process.Start(start))
            {
                CurrentProcess = process;
                if (process != null)
                {
                    process.OutputDataReceived += (s, ea) =>
                    {
                        var message = ea.Data;
                        if (!string.IsNullOrEmpty(message))
                        {
                            Results.AppendLine(message);
                            Console.WriteLine(message);
                        }
                    };
                    process.ErrorDataReceived += (s, ea) =>
                    {
                        var message = ea.Data;
                        if (!string.IsNullOrEmpty(message))
                        {
                            Errors.AppendLine(message);
                            Console.WriteLine(message);
                        }
                    };

                    //process.BeginOutputReadLine();
                    //process.BeginErrorReadLine();

                    using (StreamReader reader = process.StandardOutput)
                    {
                        var result = reader.ReadToEnd();
                        Console.Write(result);
                    }
                }

                resetEvent.Set();
                Thread.Sleep(5);
            }
        }

        private static IEnumerable<string> TailFrom(string filePath)
        {
            if (!File.Exists(filePath)) yield break;

            FileStream logFileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            StreamReader logFileReader = new StreamReader(logFileStream);

            while (!logFileReader.EndOfStream)
            {
                var line = logFileReader.ReadLine();
                if (line != null) yield return line;
                else Thread.Sleep(100);
            }

            // Clean up
            logFileReader.Close();
            logFileStream.Close();

            //using (var reader = File.OpenText(filePath))
            //{
            //    while (true)
            //    {
            //        var line = reader.ReadLine();
            //        if (reader.BaseStream.Length < reader.BaseStream.Position)
            //            reader.BaseStream.Seek(0, SeekOrigin.Begin);

            //        if (line != null) yield return line;
            //        else Thread.Sleep(100);
            //    }
            //}
            //}
            //catch (Exception excep)
            //{
            //    Console.WriteLine(excep);
            //}
        }

        private static void TailFile(string file)
        {
            foreach (string line in TailFrom(file))
            {
                Console.WriteLine($"line read= {line}");
            }
        }

        private static void ThirdTryA(ManualResetEvent resetEvent)
        {
            Results = new StringBuilder();
            Errors = new StringBuilder();
            var monitorFile = @"C:\Logs\Plot\MyLog.log";
            var batchFile = "PlotScript.py";

            var paths = ProcessRunner.GetMyScript(batchFile);
            var workingFolder = paths.workingDirectory;
            var scriptRunner = paths.scriptRunner;

            var start = new ProcessStartInfo();
            start.FileName = scriptRunner; // @"C:\Users\Basic User\AppData\Local\Programs\Python\Python38\python.exe";
            start.Arguments = $@"{batchFile} -c 18";
            //start.Arguments = $@"{batchFile} -c 18 -o {monitorFile}";
            start.UseShellExecute = false;
            start.RedirectStandardOutput = true;
            start.RedirectStandardError = true;
            start.CreateNoWindow = true;

            start.WorkingDirectory = workingFolder;
            var tt = Task.Run(() =>
            {
                while (Monitor)
                {
                    TailFile(monitorFile);
                    Thread.Sleep(500);
                }
            });

            using (var process = Process.Start(start))
            {
                CurrentProcess = process;
                if (process != null)
                {
                    process.OutputDataReceived += (s, ea) =>
                    {
                        var message = ea.Data;
                        if (!string.IsNullOrEmpty(message))
                        {
                            Results.AppendLine(message);
                            Console.WriteLine(message);
                        }
                    };
                    process.ErrorDataReceived += (s, ea) =>
                    {
                        var message = ea.Data;
                        if (!string.IsNullOrEmpty(message))
                        {
                            Errors.AppendLine(message);
                            Console.WriteLine(message);
                        }
                    };

                    //process.BeginOutputReadLine();
                    //process.BeginErrorReadLine();

                    using (StreamReader reader = process.StandardOutput)
                    {
                        var result = reader.ReadToEnd();
                        Console.Write(result);
                    }
                }

                resetEvent.Set();

                // tt.Wait();

                Thread.Sleep(5);
            }
        }

        private static void ThirdTryANoReDirect(ManualResetEvent resetEvent)
        {
            Results = new StringBuilder();
            Errors = new StringBuilder();
            var monitorFile = @"C:\Logs\Plot\MyLog.log";
            var batchFile = "PlotScript.py";

            var paths = ProcessRunner.GetMyScript(batchFile);
            var workingFolder = paths.workingDirectory;
            var scriptRunner = paths.scriptRunner;

            var start = new ProcessStartInfo();
            start.FileName = scriptRunner; // @"C:\Users\Basic User\AppData\Local\Programs\Python\Python38\python.exe";
            start.Arguments = $@"{batchFile} -c 18 -o {monitorFile}";
            start.UseShellExecute = false;
            start.RedirectStandardOutput = false;
            start.RedirectStandardError = false;
            start.CreateNoWindow = true;

            start.WorkingDirectory = workingFolder;
            var tt = Task.Run(() =>
            {
                while (Monitor)
                {
                    TailFile(monitorFile);
                    //Thread.Sleep(100);
                }
            });

            using (var process = Process.Start(start))
            {
                CurrentProcess = process;
                if (process != null)
                {
                    process.OutputDataReceived += (s, ea) =>
                    {
                        var message = ea.Data;
                        if (!string.IsNullOrEmpty(message))
                        {
                            Results.AppendLine(message);
                            Console.WriteLine(message);
                        }
                    };
                    process.ErrorDataReceived += (s, ea) =>
                    {
                        var message = ea.Data;
                        if (!string.IsNullOrEmpty(message))
                        {
                            Errors.AppendLine(message);
                            Console.WriteLine(message);
                        }
                    };

                    process.Exited += (s, ea) =>
                    {
                        Monitor = false;
                    };

                    // calls requires redirection
                    //process.BeginOutputReadLine();
                    //process.BeginErrorReadLine();

                    //using (StreamReader reader = process.StandardOutput)
                    //{
                    //    var result = reader.ReadToEnd();
                    //    Console.Write(result);
                    //}
                    //process.WaitForExit();
                }

                tt.Wait();

                resetEvent.Set();

                Thread.Sleep(5);
            }
        }

        private static void ThirdTryB(ManualResetEvent resetEvent)
        {
            Results = new StringBuilder();
            Errors = new StringBuilder();
            var monitorFile = @"C:\Logs\Plot\MyLog.log";
            var batchFile = "PlotScript.py";

            if (File.Exists(monitorFile))
            {
                File.Delete(monitorFile);
            }

            var paths = ProcessRunner.GetMyScript(batchFile);
            var workingFolder = paths.workingDirectory;
            var scriptRunner = paths.scriptRunner;

            var psi = new ProcessStartInfo();
            psi.FileName = scriptRunner; // @"C:\Users\Basic User\AppData\Local\Programs\Python\Python38\python.exe";
            psi.Arguments = $@"{batchFile} -c 3 -o monitorFile";
            psi.UseShellExecute = false;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.CreateNoWindow = true;

            psi.WorkingDirectory = workingFolder;

            using (var process = Process.Start(psi))
            {
                CurrentProcess = process;
                if (process != null)
                {
                    process.OutputDataReceived += (s, ea) =>
                    {
                        var message = ea.Data;
                        if (!string.IsNullOrEmpty(message))
                        {
                            Results.AppendLine(message);
                            Console.WriteLine(message);
                        }
                    };
                    process.ErrorDataReceived += (s, ea) =>
                    {
                        var message = ea.Data;
                        if (!string.IsNullOrEmpty(message))
                        {
                            Errors.AppendLine(message);
                            Console.WriteLine(message);
                        }
                    };

                    //process.BeginOutputReadLine();
                    //process.BeginErrorReadLine();

                    using (StreamReader reader = process.StandardOutput)
                    {
                        var result = reader.ReadToEnd();
                        Console.Write(result);
                    }
                }

                resetEvent.Set();
                Thread.Sleep(5);
            }
        }

        private static void ThirdTry(ManualResetEvent resetEvent)
        {
            ThirdTryANoReDirect(resetEvent);
        }

        private static void ThirdTryNoRedirect(ManualResetEvent resetEvent)
        {
            Results = new StringBuilder();
            Errors = new StringBuilder();
            var monitorFile = @"C:\Logs\Plot\MyLog.log";
            var batchFile = "PlotScript.py";

            var folder = Path.GetDirectoryName(monitorFile);
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            if (File.Exists(monitorFile))
            {
                File.Delete(monitorFile);
            }

            var paths = ProcessRunner.GetMyScript(batchFile);
            var workingFolder = paths.workingDirectory;
            var scriptRunner = paths.scriptRunner;

            var psi = new ProcessStartInfo();
            psi.FileName = scriptRunner; // @"C:\Users\Basic User\AppData\Local\Programs\Python\Python38\python.exe";
            psi.Arguments = $@"{batchFile} -c 3 -o monitorFile";
            psi.UseShellExecute = false;
            psi.RedirectStandardOutput = false;
            psi.RedirectStandardError = false;
            psi.CreateNoWindow = true;

            psi.WorkingDirectory = workingFolder;

            using (var process = Process.Start(psi))
            {
                CurrentProcess = process;
                if (process != null)
                {
                    process.OutputDataReceived += (s, ea) =>
                    {
                        var message = ea.Data;
                        if (!string.IsNullOrEmpty(message))
                        {
                            Results.AppendLine(message);
                            Console.WriteLine(message);
                        }
                    };
                    process.ErrorDataReceived += (s, ea) =>
                    {
                        var message = ea.Data;
                        if (!string.IsNullOrEmpty(message))
                        {
                            Errors.AppendLine(message);
                            Console.WriteLine(message);
                        }
                    };

                    //process.BeginOutputReadLine();
                    //process.BeginErrorReadLine();

                    using (StreamReader reader = process.StandardOutput)
                    {
                        var result = reader.ReadToEnd();
                        Console.Write(result);
                    }
                }

                resetEvent.Set();
                Thread.Sleep(5);
            }
        }

        private static void SecondTry(ManualResetEvent resetEvent)
        {
            var batchFile = "PlotScript.py";

            var paths = ProcessRunner.GetMyScript(batchFile);
            var workingFolder = paths.workingDirectory;
            var scriptRunner = paths.scriptRunner;

            var start = new ProcessStartInfo();
            start.FileName = scriptRunner; // @"C:\Users\Basic User\AppData\Local\Programs\Python\Python38\python.exe";
            start.Arguments = $@"{batchFile} -c 8";
            start.UseShellExecute = false;
            start.RedirectStandardOutput = true;
            start.WorkingDirectory = workingFolder;

            using (var process = Process.Start(start))
            {
                CurrentProcess = process;
                if (process != null)
                {
                    using (StreamReader reader = process.StandardOutput)
                    {
                        string result = reader.ReadToEnd();
                        Console.Write(result);
                    }
                }
            }

            resetEvent.Set();
        }

        private static void FirstTry()
        {
            var batchFile = "PlotScript.py";

            var paths1 = ProcessRunner.GetMyScript(batchFile);
            var workingFolder = paths1.workingDirectory;

            System.Diagnostics.Process process = new System.Diagnostics.Process();
            System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
            startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            startInfo.FileName = "cmd.exe";
            startInfo.Arguments = "/c \"python " + $@"{workingFolder}\{batchFile}";

            process.StartInfo = startInfo;
            process.Start();

            Console.ReadKey();
        }

        public static void RunPythonWithTimeout(int maxCount, int timeoutInSec)
        {
            // https://stackoverflow.com/questions/10788982/is-there-any-async-equivalent-of-process-start

            var pythonScript = @"MyScript.py";

            var startingFolder = Directory.GetCurrentDirectory() + @"..\..\..\";

            var extensions = new List<string> { ".py" };
            string[] files = Directory.GetFiles(startingFolder, "*.*", SearchOption.AllDirectories)
                .Where(f => extensions.IndexOf(Path.GetExtension(f)) >= 0)
                .ToArray();

            var specificScript = files.FirstOrDefault(file => file.EndsWith(pythonScript));

            var selectedScriptPath = Path.GetFullPath(specificScript);

            var workingDirectory = Path.GetDirectoryName(selectedScriptPath);

            var pythonCommand = "python.exe";
            var pythonPath = GetPath(pythonCommand);
            var pythonFullPath = Path.Combine(pythonPath, pythonCommand);

            var scriptArgs = $"{selectedScriptPath} -l {maxCount}";

            var task = Task.Run(async () =>
            {
                await RunProcessExeAsync(workingDirectory, pythonFullPath, scriptArgs);
            });

            if (task.Wait(timeoutInSec * 1000))
            {
                Console.WriteLine("The Process is Complete on time.");
            }
            else
            {
                Console.WriteLine("The Process timed out, force termination.");
                CurrentProcess.Kill();
            }

            if (Results.Length > 0)
            {
                Console.WriteLine("Results:");
                Console.WriteLine(Results);
            }
            if (Errors.Length > 0)
            {
                Console.WriteLine("Errors:");
                Console.WriteLine(Errors);
            }
        }

        public static async Task<int> RunProcessExeAsync(string workingFolder, string fileName, string args)
        {
            Results = new StringBuilder();
            Errors = new StringBuilder();

            using (var process = new Process
                   {
                       StartInfo =
                       {
                           FileName = fileName,
                           Arguments = args,
                           UseShellExecute = false,
                           CreateNoWindow = true,
                           RedirectStandardOutput = true,
                           RedirectStandardError = true,
                           WorkingDirectory = workingFolder
                       },
                       EnableRaisingEvents = true
                   })
            {
                CurrentProcess = process;

                await RunProcessAsync(process).ConfigureAwait(false);
            }

            return 0;
        }

        private static Task<int> RunProcessAsync(Process process)
        {
            var tcs = new TaskCompletionSource<int>();

            process.Exited += (s, ea) => tcs.SetResult(process.ExitCode);
            process.OutputDataReceived += (s, ea) =>
            {
                var message = ea.Data;
                if (!string.IsNullOrEmpty(message))
                {
                    Results.AppendLine(message);
                    Console.WriteLine(message);
                }
            };
            process.ErrorDataReceived += (s, ea) =>
            {
                var message = ea.Data;
                if (!string.IsNullOrEmpty(message))
                {
                    Errors.AppendLine(message);
                    Console.WriteLine(message);
                }
            };

            bool started = process.Start();
            if (!started)
            {
                //you may allow for the process to be re-used (started = false) 
                //but I'm not sure about the guarantees of the Exited event in such a case
                throw new InvalidOperationException("Could not start process: " + process);
            }

            process.BeginOutputReadLine();
            process.BeginErrorReadLine();

            return tcs.Task;
        }


        public static void RunPython1(int maxCount, int timeLimit)
        {
            var pythonScript = @"MyScript.py";

            var startingFolder = Directory.GetCurrentDirectory() + @"..\..\..\";

            var extensions = new List<string> { ".py" };
            string[] files = Directory.GetFiles(startingFolder, "*.*", SearchOption.AllDirectories)
                .Where(f => extensions.IndexOf(Path.GetExtension(f)) >= 0)
                .ToArray();

            var specificScript = files.FirstOrDefault(file => file.EndsWith(pythonScript));

            if (specificScript == null)
            {
            }

            var selectedScriptPath = Path.GetFullPath(specificScript);

            var workingDirectory = Path.GetDirectoryName(selectedScriptPath);

            var pythonCommand = "python.exe";
            var pythonPath = GetPath(pythonCommand);
            var pythonFullPath = Path.Combine(pythonPath, pythonCommand);

            var scriptArgs = $"{selectedScriptPath} -l {maxCount}";

            _ = ProcessRunner.ExecuteShellCommand(pythonFullPath, scriptArgs, timeLimit);
        }

     
        private static void InterProcOutputHandler(object sendingProcess, DataReceivedEventArgs outLine)
        {
            Console.WriteLine(outLine.Data);
        }

        private static string GetPath(string executableName)
        {
            string result = Environment
                .GetEnvironmentVariable("PATH")
                ?.Split(';')
                .FirstOrDefault(s => File.Exists(Path.Combine(s, executableName)));

            return result;
        }

        private static void RunScript(string scriptCmd = @"RunScript.cmd", string args = "")
        {
            var pythonScript = @"RunScript.cmd";

            var startingFolder = Directory.GetCurrentDirectory() + @"..\..\..\";

            var extensions = new List<string> { ".cmd" };
            string[] files = Directory.GetFiles(startingFolder, "*.*", SearchOption.AllDirectories)
                .Where(f => extensions.IndexOf(Path.GetExtension(f)) >= 0)
                .ToArray();

            var specificScript = files.FirstOrDefault(file => file.EndsWith(pythonScript));

            if (specificScript == null)
            {
                return;
            }

            var selectedScriptPath = Path.GetFullPath(specificScript);

            ProcessStartInfo processStartInfo = new ProcessStartInfo();
            processStartInfo.FileName = selectedScriptPath;
            if (!string.IsNullOrEmpty(args))
                processStartInfo.Arguments = $"{selectedScriptPath} {args}";
            processStartInfo.UseShellExecute = false;
            processStartInfo.RedirectStandardOutput = true;
            var workingDirectory = Path.GetDirectoryName(selectedScriptPath);

            if (workingDirectory != null) processStartInfo.WorkingDirectory = workingDirectory;

            using (Process process = Process.Start(processStartInfo))
            {
                if (process != null)
                {
                    process.OutputDataReceived += new DataReceivedEventHandler(InterProcOutputHandler);
                    process.ErrorDataReceived += new DataReceivedEventHandler(InterProcOutputHandler);

                    process.WaitForExit(10000000);
                }
            }
        }

        private void RunPython(string cmd, string args)
        {
            ProcessStartInfo start = new ProcessStartInfo();
            start.FileName = "python.exe";
            start.Arguments = string.Format("{0} {1}", cmd, args);
            start.UseShellExecute = false;
            start.RedirectStandardOutput = true;
            using (Process process = Process.Start(start))
            {
                if (process != null)
                    using (StreamReader reader = process.StandardOutput)
                    {
                        string result = reader.ReadToEnd();
                        Console.Write(result);
                    }
            }
        }

        private static async Task<int> RunProcessAsync1(Process process, int timeout)
        {
            var tcs = new TaskCompletionSource<int>();

            process.Exited += (s, ea) => tcs.SetResult(process.ExitCode);
            process.OutputDataReceived += (s, ea) =>
            {
                Results.AppendLine(ea.Data).Append(Environment.NewLine);
                Console.WriteLine(ea.Data);
            };
            process.ErrorDataReceived += (s, ea) =>
            {
                Errors.AppendLine(ea.Data).Append(Environment.NewLine);
                Console.WriteLine(ea.Data);
            };

            bool started = process.Start();
            if (!started)
            {
                //you may allow for the process to be re-used (started = false) 
                //but I'm not sure about the guarantees of the Exited event in such a case
                throw new InvalidOperationException("Could not start process: " + process);
            }

            process.BeginOutputReadLine();
            process.BeginErrorReadLine();

            ////
            var waitForExit = WaitForExitAsync(process, timeout);

            var outputBuilder = new StringBuilder();
            var errorBuilder = new StringBuilder();
            var outputCloseEvent = new TaskCompletionSource<bool>();
            var errorCloseEvent = new TaskCompletionSource<bool>();
            var result = new ProcessResult();

            // Create task to wait for process exit and closing all output streams
            var processTask = Task.WhenAll(waitForExit, outputCloseEvent.Task, errorCloseEvent.Task);

            // Waits process completion and then checks it was not completed by timeout
            if (await Task.WhenAny(Task.Delay(timeout), processTask) == processTask && waitForExit.Result)
            {
                result.Completed = true;
                result.ExitCode = process.ExitCode;

                // Adds process output if it was completed with error
                if (process.ExitCode != 0)
                {
                    result.Output = $"{outputBuilder}{errorBuilder}";
                }
            }
            else
            {
                try
                {
                    // Kill hung process
                    process.Kill();
                }
                catch
                {
                }
            }

            //// https://stackoverflow.com/questions/70622033/waitforexitasync-with-a-timeout

            //var timeoutSignal = new CancellationTokenSource(TimeSpan.FromSeconds(3));
            //try
            //{
            //    //await process.WaitForExitAsync(timeoutSignal.Token);
            //    Console.WriteLine("Ping has been Finished");
            //}
            //catch (OperationCanceledException)
            //{
            //    process.Kill();
            //    Console.WriteLine("Ping has been Terminated");
            //}

            return await tcs.Task;
        }

        private static Task<bool> WaitForExitAsync(Process process, int timeout)
        {
            return Task.Run(() => process.WaitForExit(timeout));
        }

    }

    public struct ProcessResult
    {
        public bool Completed;
        public int? ExitCode;
        public string Output;
    }

    // https://gist.github.com/AlexMAS/276eed492bc989e13dcce7c78b9e179d

}



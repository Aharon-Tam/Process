import sys
import pyodbc
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


if len(sys.argv) == 2:
    server = '.'
    database = 'Book'
    try:
        conexion = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';Trusted_Connection=yes;')
        cursor = conexion.cursor()
                        
    except Exception as e:
        print("Error SQL Server: ",e)
    
    card = sys.argv[1]
    my_dpi= 96

    consulta = "SELECT qt_x from tb_value WHERE cd_card = "+str(card)+";"
    cursor.execute(consulta)
    img_x = cursor.fetchall()

    consulta = "SELECT qt_y from tb_value WHERE cd_card = "+str(card)+";"
    cursor.execute(consulta)
    img_y = cursor.fetchall()

    consulta = "SELECT max(qt_y) from tb_value WHERE cd_card = "+str(card)+";"
    cursor.execute(consulta)
    maxy = float(cursor.fetchval())
    y_tope = maxy + 1

    fig, catc = plt.subplots(figsize=(96/my_dpi,96/my_dpi))
    catc.plot(img_x,img_y, "black")

    catc.set_axis_off()
    limx= catc.get_xlim()
    limy= catc.get_ylim()
    catc.set_ylim((y_tope/2)*-1,y_tope)

    catc= plt.gcf()

    figname = 'cdg_{}.jpg'.format(card)
    path = r"C:\Users\basic user\Desktop\BSC\BasicProg\BasicProg\bin\Debug\cards"
    dest = os.path.join(path, figname)
    catc.savefig(dest, dpi=96)
    
else:
    print("Error - Introduce los argumentos correctamente")
    print("Ejemplo: graphbasiccard.py Carta ")

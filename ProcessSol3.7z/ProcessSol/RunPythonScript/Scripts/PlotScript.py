from time import sleep
import matplotlib.pyplot as plt
import numpy as np
import datetime
import os
import sys
from datetime import datetime
#import argparse
import sys
import getopt

e_Count = None
out_file = None

argv = sys.argv[1:]

try:
    opts, args = getopt.getopt(argv, "c:o:")
except:
    print("Error")

for opt, arg in opts:
    if opt in ['-c']:
        e_Count = arg
    elif opt in ['-o']:
        out_file = arg

orig_stdout = sys.stdout

if out_file is not None:
    import os

    try:
        out_path = os.path.dirname(out_file)
        os.makedirs(out_path, exist_ok=True)

        f = open(out_file, 'w+')
        sys.stdout = f
    except Exception as err:
        print(f"Exception caught {err=}, {type(err)=}")

# parser = argparse.ArgumentParser(description='Plotter Example')
# parser.add_argument('-c','--count', help='Simulate Long Process', required=False)
# parser.add_argument('-o','--outfile', help='output messages file', required=False)

# try:
#     args = parser.parse_args()
# except Exception as exp:
#     msg = f'Failed to upload to ftp: {exp}'
#     print(msg)
# except:
#     print("System Error")    

# if args.count is not None:
#     xCount = int(args.count)
#     print(f"count = {xCount}")

# if args.outfile is not None:
#     outfile = args.outfile
#     print(f"outfile = {outfile}")

# if outfile is not None:
#     orig_stdout = sys.stdout
#     f = open(outfile, 'w')
#     sys.stdout = f

# X axis parameter:
xaxis = np.array([2, 8])

# Y axis parameter:
yaxis = np.array([4, 9])

plt.plot(xaxis, yaxis)
# plt.show()
import time
xCount = int(e_Count)
xRun = 0

print(xaxis)
print(yaxis)

now = datetime.now() # current date and time
timestamp = now.strftime("%Y%m%d_%H%M%S")

figname = f'cdg_{timestamp}.jpg'

dir_path = os.path.dirname(os.path.realpath(__file__))

path = r".\Images"
full_path = os.path.join(dir_path, '.', 'Images')
if not os.path.exists(full_path):
      
    # if the demo_folder directory is not present 
    # then create it.
    os.makedirs(full_path)

dest_file = os.path.join(full_path, figname)
plt.savefig(dest_file, dpi=96)

while xRun < xCount:
    x = xCount
    while x > 0:
        print(f"[{x}] hello friend")
        x = x - 1;
        time.sleep(0.5)

    time.sleep(0.3)
    xRun = xRun + 1

print('done ...')

if out_file is not None:
    sys.stdout = orig_stdout
    f.close()
